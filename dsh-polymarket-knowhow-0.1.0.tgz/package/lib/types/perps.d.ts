/**
 * Client for Polymarket Perps — perpetual futures (NEW API surface).
 *
 * Base URL: https://api.perpetuals.polymarket.com
 * Auth (account/trade groups): `POLYMARKET-PROXY` (proxy address) and
 * `POLYMARKET-SECRET` headers. `/v1/info/*` endpoints are public.
 *
 * WebSocket: wss://ws.perpetuals.polymarket.com (~27 channels) is documented
 * in knowledge/perps.md but not bridged by this plugin yet.
 */
import { type HttpConfig } from './http.js';
export interface PerpsCredentials {
    proxy: string;
    secret: string;
}
export declare class PerpsClient {
    private readonly baseUrl;
    private readonly http;
    private credentials?;
    constructor(baseUrl: string, http: HttpConfig, credentials?: PerpsCredentials | undefined);
    setCredentials(creds: PerpsCredentials): void;
    hasCredentials(): boolean;
    private info;
    private authed;
    ping(): Promise<unknown>;
    serverTime(): Promise<unknown>;
    exchangeInfo(): Promise<unknown>;
    collateralAssets(): Promise<unknown>;
    instruments(params?: {
        instrument?: string;
    }): Promise<unknown>;
    tickers(params?: {
        instrument?: string;
    }): Promise<unknown>;
    bestBidOffer(params: {
        instrument: string;
    }): Promise<unknown>;
    book(params: {
        instrument: string;
        depth?: number;
    }): Promise<unknown>;
    klines(params: {
        instrument: string;
        interval: string;
        start_timestamp?: number;
        end_timestamp?: number;
    }): Promise<unknown>;
    markPriceHistory(params: {
        instrument: string;
        start_timestamp?: number;
        end_timestamp?: number;
    }): Promise<unknown>;
    index(): Promise<unknown>;
    recentTrades(params: {
        instrument: string;
    }): Promise<unknown>;
    publicPortfolio(address: string): Promise<unknown>;
    fundingHistory(params: {
        instrument: string;
        start_timestamp?: number;
        end_timestamp?: number;
    }): Promise<unknown>;
    fees(): Promise<unknown>;
    statistics(): Promise<unknown>;
    balances(): Promise<unknown>;
    accountPortfolio(): Promise<unknown>;
    fills(params?: {
        instrument?: string;
    }): Promise<unknown>;
    openOrders(): Promise<unknown>;
    ordersHistory(): Promise<unknown>;
    pnl(): Promise<unknown>;
    fundingPayments(): Promise<unknown>;
    deposits(): Promise<unknown>;
    withdrawals(): Promise<unknown>;
    limits(): Promise<unknown>;
    rewards(): Promise<unknown>;
    stats(): Promise<unknown>;
    /** Create orders. Payload shape follows `POST /v1/trade/orders`; pass through as-is. */
    createOrders(payload: unknown): Promise<unknown>;
    cancelOrder(payload: unknown): Promise<unknown>;
    cancelOrderByClientOrderId(payload: unknown): Promise<unknown>;
    cancelAllOrders(): Promise<unknown>;
    setLeverage(payload: unknown): Promise<unknown>;
}
